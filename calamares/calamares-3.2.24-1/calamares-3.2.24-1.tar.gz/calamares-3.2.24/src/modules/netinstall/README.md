# Netinstall module

All of the actual documentation of the netinstall module has moved
into the `netinstall.conf` file; since the configuration file **may**
contain the groups-and-packages list itself, that format is
also described there.
