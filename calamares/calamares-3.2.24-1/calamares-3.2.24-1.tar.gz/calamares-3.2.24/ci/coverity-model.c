/* Model file for Coverity checker.
  See https://scan.coverity.com/tune

  Calamares doesn't seem to geenerate any false positives,
  so the model-file is empty.
*/
